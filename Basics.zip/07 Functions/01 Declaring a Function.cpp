#include <iostream>

using namespace std;
// Function declaration
int make_juice(int water_glass, int fruit);
// int make_juice(int , int);

int main() {

  return 0;
}