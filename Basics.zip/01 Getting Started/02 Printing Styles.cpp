// #include <iostream>

// using namespace std;

// int main() {
//   cout << "Hello ";
//   cout << "World";
// }




#include <iostream>

using namespace std;

int main() {
  cout << "Hello " << endl;
  cout << "World";
}

