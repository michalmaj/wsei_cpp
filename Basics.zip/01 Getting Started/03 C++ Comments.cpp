// Single line comments
#include <iostream>

using namespace std;
int main() {
  // I am a single-line comment
  // Compiler will ignore me
  // cout << "Hey"
  cout << "Hello World";
}

// Multiline comments
#include <iostream>

using namespace std;
int main() {
  /* I am a multi-line comment
  Compiler will ignore me
  cout << "Hey" */
  cout << "Hello World";
}

// White spaces
#include <iostream>

using namespace std;

int main() {




  cout    <<   "Hello World";

}