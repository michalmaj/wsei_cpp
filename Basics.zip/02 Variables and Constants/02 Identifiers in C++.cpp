#include <iostream>

using namespace std;

int main() {

    // Example program with valid identifiers
    int number1;
    int _number;
    int number;

    // Example program with invalid identifiers (The program given below will generate an error.)
    // int 1;
    // int number 1;
    // int return;

}