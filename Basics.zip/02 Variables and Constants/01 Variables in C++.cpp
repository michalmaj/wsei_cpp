#include <iostream>

using namespace std;

int main() {
  // Declares a variable current_amount
  int current_amount;
  // Initialize a variable current_amount to 100
  current_amount = 100;
  // Prints the value of current_amount
  cout << "Your current amount is: " << current_amount << endl;
  // Updates the value of current_amount
  current_amount = 120;
  // Prints the updated value of current_amount
  cout << "Your current amount is: " << current_amount << endl;
}