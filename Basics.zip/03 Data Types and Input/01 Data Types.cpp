#include <iostream>

using namespace std;

int main() {
  int number = 10;
  cout << "Number = " << number << endl;
  cout << INT_MIN << endl;
  cout << INT_MAX << endl;
}