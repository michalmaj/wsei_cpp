#include <iostream>

using namespace std;

int main() {
  // Initialize a string variable
  string text = "Hey12345";
  // Displays value of string variable
  cout << text << endl;


  // Initialize string variable with text and escape characters
  text = "Hello\nI\tam\tJohn";
  // Displays value of string variable
  cout << text << endl;
}