#include <iostream>

using namespace std;

int main() {
  // Declares variable
  float number;
  // Displays text
  cout << "Please enter your number:" << endl;
  // Waits for the user input
  cin >> number;
  // Displays entered number
  cout << "You have entered: " << number << endl;
}