#include <iostream>
using namespace std;

int main() {
  // Initialize variable
  int number = 2147483649;
  // Display variable value
  cout << number << endl;

    // Initialize variables
  int integer = 2147483649;
  long int long_integer = 2147483649;
  // Display variables value
  cout << "integer = " << integer << endl;
  cout << "long_integer = " << long_integer << endl;

    // Initialize variables
  integer = 32768;
  short int short_integer = 32768;
  // Display variables value
  cout << "integer = " << integer << endl;
  cout << "short_integer = " << short_integer << endl;

   // Initialize variables 
  integer = -10;
  unsigned int unsigned_integer = -10;

  char character = 'A';
  unsigned char unsigned_character = 'B';
  // Display variables value
  cout << "integer = " << integer << endl;
  cout << "unsigned_integer = " << unsigned_integer << endl;

  cout << "character = " << character << endl;
  cout << "unsigned_character = " << unsigned_character << endl;

    // Initialize variables
  integer = -90;
  signed int signed_integer = -90;

  character = 'A';
  signed char signed_character = 'A';
  // Display variables value
  cout << "integer = " << integer << endl;
  cout << "signed_integer = " << signed_integer << endl;

  cout << "character = " << character << endl;
  cout << "signed_character = " << signed_character << endl;


 
}