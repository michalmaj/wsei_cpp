#include <iostream>
using namespace std;

int main() {
  // Initilaize operand1 and operand2
  int int_operand1 = 50;
  int int_operand2 = 26;
  // Prints value of operand1 and operand2
  cout << "Values of operands are:" << endl;
  cout << "operand1 = " << int_operand1 << " , operand2 = " << int_operand2 << endl;
  // Adds operand1 and operand2; and print their result
  cout << "Addition = " << int_operand1 + int_operand2 << endl;
  // Subtracts operand1 and operand2; and print their result
  cout << "Subtraction = " << int_operand1 - int_operand2 << endl;
  // Multiplies operand1 and operand2; and print their result
  cout << "Multiplication = " << int_operand1 * int_operand2 << endl;
  // Divides operand1 and operand2; and print their result
  cout << "Division = " << int_operand1 / int_operand2 << endl;
  // Returns remainder of operand1 and operand2; and print it
  cout << "Modulus = " << int_operand1 % int_operand2 << endl;


// Initilaize operand1 and operand2
 float float_operand1 = 50.0;
 float float_operand2 = 26.0;
  // Prints value of operand1 and operand2
  cout << "Values of operands are:" << endl;
  cout << "operand1 = " << float_operand1 << " , operand2 = " << float_operand2 << endl;
  // Adds operand1 and operand2; and print their result
  cout << "Addition = " << float_operand1 + float_operand2 << endl;
  // Subtracts operand1 and operand2; and print their result
  cout << "Subtraction = " << float_operand1 - float_operand2 << endl;
  // Multiplies operand1 and operand2; and print their result
  cout << "Multiplication = " << float_operand1 * float_operand2 << endl;
  // Divides operand1 and operand2; and print their result
  cout << "Division = " << float_operand1 / float_operand2 << endl;
  // Returns remainder of operand1 and operand2; and print it
  //cout << "Modulus = " << operand1 % operand2 << endl;

  return 0;
}