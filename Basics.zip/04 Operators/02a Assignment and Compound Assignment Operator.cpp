#include <iostream>
using namespace std;

int main() {
  //Assigns value to the operands
  int operand1 = 50;
  float operand2 = 26;
  double operand3 = 78;
  bool operand4 = true;
  char operand5 = 'A';
  string operand6 = "Welcome";

  // Prints value of the operands
  cout << "operand1 = " << operand1 << endl;
  cout << "operand2 = " << operand2 << endl;
  cout << "operand3 = " << operand3 << endl;
  cout << "operand4 = " << operand4 << endl;
  cout << "operand5 = " << operand5 << endl;
  cout << "operand6 = " << operand6 << endl;
  return 0;
}