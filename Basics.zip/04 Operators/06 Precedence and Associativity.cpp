#include <iostream>
using namespace std;

int main() {
  cout << 4-(8+10)*3 << endl; // PEMDAS
}