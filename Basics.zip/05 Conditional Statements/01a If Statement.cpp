// Example program when the condition is true
#include <iostream>

using namespace std;

int main() {
  // Initialize money to 21
  int money = 21;
  // If condition
  if (money >= 20) {
    // If body  
    cout << "You can buy a watch" << endl;
  }
  // Exit 
  return 0;
}