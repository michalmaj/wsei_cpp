#include <iostream>

using namespace std;

int main() {
  // Initialize variable money
  int money = 9;
  // if condition
  if (money >= 20) {
    // if body  
    cout << "You can buy a watch" << endl;
  }
  // exit
  return 0;
}