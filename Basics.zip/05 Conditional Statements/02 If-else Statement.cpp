#include <iostream>

using namespace std;

int main() {
  // Initialize variable money
  int money = 10;
  // if condition
  if (money >= 20) {
    // if block  
    cout << "You can gift a watch" << endl;
  } else {
    // else block
    cout << "You can gift a pen " << endl;
  }
  return 0;
}