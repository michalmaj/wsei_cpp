#include <iostream>

using namespace std;

int main() {
  for ( ; ;){
    cout << "Hey, I am infinite loop" << endl;
  }

  return 0;
}