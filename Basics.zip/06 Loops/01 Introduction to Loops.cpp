#include <iostream>

using namespace std;

int main() {
  int number = 0;
  cout << number++ << endl;
  cout << number++ << endl;
  cout << number++ << endl;
  cout << number++ << endl;
  cout << number++ << endl;
  return 0;
}