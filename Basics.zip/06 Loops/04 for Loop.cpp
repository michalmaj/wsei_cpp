#include <iostream>

using namespace std;

int main() {
  // Initialize variable icecream
  int icecream;
  // for loop start
  for (icecream = 5; icecream > 0; icecream--) {
    // loop body
    cout << "Number of free icecream = " << icecream << endl;
    cout << "Buy an icecream" << endl;
  }
  // Exit loop
  return 0;
}